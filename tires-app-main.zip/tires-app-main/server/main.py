from flask import Flask, make_response, jsonify, request
from dotenv import load_dotenv

from core_api.Tire import Tire
from core_api.Participant import Participant

load_dotenv()
app = Flask(__name__)

tire_obj = Tire()
tire_obj.initialize()

@app.route('/')
def base_path():
    return "Not implemented", 501

@app.route('/init')
def init():
    tire_obj = Tire()
    tire_obj.initialize()
    return "Complete", 200

@app.route('/tires', methods=['GET', 'POST'])
def tire_entity():
    if request.method == 'GET':
        tire_obj = Tire()
        return tire_obj.get_tires()
    elif request.method == 'POST':
        content_type = request.headers.get('Content-Type')
        if content_type == 'application/json':
            payload = request.json
            try:
                tire_obj = Tire()
                rsp = tire_obj.create_tires(payload=payload)
                response = make_response(rsp.text, rsp.status_code)
                response.headers["Content-Type"] = "application/json"
                return response
            except ValueError as e:
                return 'Bad Request', 400
        else:
            return 'Content-Type not supported!', 400


if __name__ == '__main__':
    app.run()
    init()

