# Tire Managment server

The Tire Management server provides the connection to the OS1 Platform for the [Tire Management client](../client/). It is written in Python and uses flask to expose endpoint calls to retrieve and update the information about the tires in the system.

## OS1 APIs used by the server

The Tire Managment server uses the following

- Entity Service [Conceptupal Documentation](https://docs.os1.delhivery.com/docs/entity-1) [API Reference](https://docs.os1.delhivery.com/reference/entity-type): Provides the endpoints to define, update, and retrieve a tire from the platform.
- Participant Service [Conceptupal Documentation](https://docs.os1.delhivery.com/docs/participant) [API Reference](https://docs.os1.delhivery.com/reference/participant-type-1): Provides endpoints to create a new participant type.
- Authentication And Authorization Service [Conceptupal Documentation](https://docs.os1.delhivery.com/docs/authentication-and-authorisation) [API Reference](https://docs.os1.delhivery.com/reference/authentication): Provides the endpoint to authorize and authenticate the client App on OS1 Platform.


The primary source files that you need to be aware of if you choose to extend the server are:

- In the root folder of the server: 
    - main.py: Exposes endpoints that the client can call.
- In the core_api folder:
    - Participant.py: Provides Participant management support.
    - Tire.py: Provides tire management support.

## Server setup

To setup the servier, you must create an environment file that contains information necessary to authenticate the App and to access the correct platform resources. You must also install the necessary dependencies to run the server.

### Add the env file

In the root folder of the server, add a `.env` file and copy the following key/value pair to the file:

```
OS1_CLIENT_ID=<client id>
OS1_APP_ID=<client id>
OS1_CLIENT_SECRET=<secret>
OS1_DEFAULT_AUDIENCE=platform:app:coreos
OS1_PROTOCOL=https
OS1_TENANT=<tenant>
OS1_BASE_URL=<tenant-url>
```

Open the OS1 [Platform Developer Portal](https://portal.os1.delhivery.com/).

Replace the placeholder values, with the appropriate values for your Tenant and App. 

For more information about registering Apps, see [Getting started with building Apps](https://docs.os1.delhivery.com/docs/getting-started-building-apps#register-an-app) in the official documentation.


### Install dependencies

To install the necessary dependencies, run the following command:

`pip3 install -r requirements.txt`

## Run the server

To start the server, run the following command;

`python3 main.py`
