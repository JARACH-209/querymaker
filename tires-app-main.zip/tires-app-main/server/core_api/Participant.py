import json
import os

from flask import Flask, make_response, jsonify, request
import requests
import uuid
from utils_api.Authorization import Authorization
from utils_api.OS1Common import OS1Common


class Participant:
    url = ''

    def __init__(self):
        self.url = os.getenv('OS1_BASE_URL')
        return

    def initialize(self):
        path = '/core/api/v1/participants/participant-types'
        headers = OS1Common.get_headers()
        payload = {}

        rsp = requests.request("GET", self.url + path, headers=headers, data=payload)

        data = json.loads(rsp.text)
        participant_types = data['data']['participantTypes']
        if participant_types:
            for participant_type in participant_types:
                if participant_type['name']['plural']:
                    print(participant_type['name']['plural'])

        return True

    def get_all_participant_type(self):

        path = '/core/api/v1/participants/participant-types'
        headers = OS1Common.get_headers()
        payload = {}

        rsp = requests.request("GET", self.url + path, headers=headers, data=payload)
        if rsp.status_code == requests.codes.ok:
            response = make_response(rsp.text, 200)
            response.headers["Content-Type"] = "application/json"
            return response
        else:
            return 'Bad Request', 400

    def create_participant_type(self, payload):
        path = '/core/api/v1/participants/participant-types'
        headers = OS1Common.get_headers()

        rsp = requests.request("POST", self.url + path, headers=headers, data=json.dumps(payload))
        if rsp.status_code == requests.codes.ok:
            response = make_response(rsp.text, 200)
            response.headers["Content-Type"] = "application/json"
            return response
        else:
            return 'Bad Request', 400

    def create_participant(self, payload):
        return None

    def get_participant_by_id(self, participant_plural_name, id):
        path = '/core/api/v1/participants/{}/{}'.format(participant_plural_name, id)
        headers = OS1Common.get_headers()
        payload = {}

        rsp = requests.request("GET", self.url + path, headers=headers, data=payload)
        if rsp.status_code == requests.codes.ok:
            response = make_response(rsp.text, 200)
            response.headers["Content-Type"] = "application/json"
            return response
        else:
            return 'Bad Request', 400
