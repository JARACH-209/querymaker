import json
import os
import requests
from flask import make_response
from utils_api.OS1Common import OS1Common


class Tire:
    url = ''
    entity_type_name = "Tires"
    entity_type_id = ''

    def __init__(self):
        self.url = os.getenv('OS1_BASE_URL')
        self.tenant_id = os.getenv('OS1_TENANT')
        return

    def initialize(self):
        entity_found = False;
        app_id = os.getenv('OS1_APP_ID')
        path = '/core/api/v1/entity-service/apps/{}/entity-type'.format(app_id)
        headers = OS1Common.get_headers()
        payload = {}

        rsp = requests.request("GET", self.url + path, headers=headers, data=payload)
        data = json.loads(rsp.text)
        entity_types = data['data']['entityTypes']
        if entity_types:
            for entity_type in entity_types:
                if entity_type['name']['plural'] == self.entity_type_name:
                    self.entity_type_id = entity_type['id']
                    entity_found = True
                    break

        if not entity_found:
            return self.create_tire_entity_type()

        return False

    def create_tire_entity_type(self):

        payload = """
        {
           "name":{
              "plural":"Tires",
              "singular":"Tire"
           },
           "coreAttributes":[
              {
                 "name":"rimdiameter",
                 "dataType":"string",
                 "indexed":false
              },
              {
                 "name":"rimwidth",
                 "dataType":"string",
                 "indexed":false
              },
              {
                 "name":"treaddepth",
                 "dataType":"string",
                 "indexed":false
              },
              {
                 "name":"isnew",
                 "dataType":"boolean",
                 "indexed":false
              }
           ]
        }
        """

        app_id = os.getenv('OS1_APP_ID')
        path = '/core/api/v1/entity-service/apps/{}/entity-type'.format(app_id)
        headers = OS1Common.get_headers()

        rsp = requests.request("POST", self.url + path, headers=headers, data=payload)
        if ((rsp.status_code == requests.codes.ok) or (rsp.status_code == 201)):
            data = rsp.json()
            self.entity_type_id = data['data']['id']
            print(self.entity_type_id)
            return True
        else:
            return False

    def create_tires(self, payload):
        app_id = os.getenv('OS1_APP_ID')
        path = '/core/api/v1/entity-service/apps/{}/{}'.format(app_id, self.entity_type_name)
        headers = OS1Common.get_headers()
        rsp = requests.request("POST", self.url + path, headers=headers, data=json.dumps(payload))

        return rsp

    def get_tires(self):
        app_id = os.getenv('OS1_APP_ID')
        payload = {}
        path = '/core/api/v1/entity-service/apps/{}/{}'.format(app_id, self.entity_type_name)
        headers = OS1Common.get_headers()

        rsp = requests.request("GET", self.url + path, headers=headers, data=payload)
        response = make_response(rsp.text, 200)
        response.headers["Content-Type"] = "application/json"
        return response
