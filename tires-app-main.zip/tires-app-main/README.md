# Tires App sample

A simple full-stack App for displaying and editing tires.
The App consists of a server that provides access to the OS1 Platform resources and a web client that provides a broswer based UI.

## Prerequisites

- A terminal in which you can run bash scripts
- Python 3
- node
- yarn (recommended)

## Usage

For instructions on how to run the server and client, see the READMEs in the following folders:

- [server/](server)
- [client/](client)
