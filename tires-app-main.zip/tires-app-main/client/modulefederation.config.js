const deps = require('./package.json').dependencies;

const {HEADER_URL} = require('consoleui-library');

module.exports = {
  remotes: {
    header: HEADER_URL,
  },
  exposes: {},
  shared: {
    ...deps,
    react: {
      singleton: true,
      requiredVersion: deps.react,
    },
    'react-dom': {
      singleton: true,
      requiredVersion: deps['react-dom'],
    },
  },
};
