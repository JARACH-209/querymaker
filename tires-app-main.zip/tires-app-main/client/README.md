# Tire Management client

The Tire Management client implements a browser-based frontend written in React that provides a user-interface to create and view tires.

It calls endpoints on the [Tire Management server](../server/) to retrieve and manage tires in your organization.

The App provides a minimal implementation and does not provide input validation. To create a tire, the App accepts the following inputs:

- Name: A name for the tire. A string value matching the follow pattern ^[a-zA-Z0-9][a-zA-Z0-9_:-]{0,127}.
- Code: This is a unique code to identify the tire. A string value matching the follow pattern ^[a-zA-Z0-9][a-zA-Z0-9_:-]{0,63}.
- Owner: A string value containing the owner of the tire.
- Rim Diameter: A string value describing the rim diameter. For example, 18 in or 47 CM.
- Rim Width: A string value describing the rim width.
- Tread depth: A string value describing the tread depth.

All values are mandatory.

To extend the App, you will primarily be working with the files in the src\pages\Tires folder.

## Client setup

To setup the client, you must configure a proxy in your hosts file and intall the necessary dependencies.

### Configure proxy

Add the proxy `127.0.0.1 <tenant-host>` to the hosts file. Replace `<tenant-host>` with the host part of your tenant url, but add a `-cdev` after the first part of the domain. For example, if the tenant url is `https://dlvindia.preprod.dlv2.fxtrt.io`, then the host will be `dlvindia-cdev.preprod.dlv2.fxtrt.io`.

### Install dependencies

Run `yarn` or `npm i`

## Run

To run the Tire Management client:

1. If the server is not already running, follow the directions to run the server located in the [Tire Management server](../server/) README.
2. In the root folder of the client, start the web client by running the command `TENANT_URL=<tenant-url> yarn start` in your terminal. Replace `<tenant-url>` with your tenant url. For example, the tenant url from above is `https://dlvindia.preprod.dlv2.fxtrt.io`.
3. A browser window will open. There might be a security warning which can be ignored.

**Note**: If you are running the commands on the Windows OS, we recommend that you use a Bash shell.
