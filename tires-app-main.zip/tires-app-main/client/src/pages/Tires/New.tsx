import { Switch } from '@headlessui/react';
import { FunctionComponent, useCallback, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';

import { ITire, postTire, useGetTires } from '../../api/tires';
import { classNames } from '../../helpers/classNames';
import { getUniqueId } from '../../helpers/getUniqueId';
import { properties } from './Tire';

export const NewTire: FunctionComponent = () => {
  const { register, handleSubmit } = useForm<ITire>({
    defaultValues: {
      uniqueCode: getUniqueId(),
    },
  });

  const { refetch } = useGetTires();

  const navigate = useNavigate();
  const returnOneStep = useCallback(() => {
    navigate('..', { replace: true });
  }, []);
  const [isNew, setIsNew] = useState(false);

  const onSubmit = useCallback(
    async (data: any) => {
      (data as ITire).properties.isnew = isNew;

      const createdTireId = await postTire(data);
      if (createdTireId) {
        refetch();
        navigate(`/tires/${createdTireId}`);
      }
    },
    [isNew]
  );

  return (
    <main className="flex-1">
      <div className="px-4 sm:px-6 md:px-8 space-y-6 max-w-7xl">
        <div className="sm:flex sm:items-center">
          <div className="sm:flex-auto">
            <h1 className="text-xl font-semibold text-gray-900">
              Create a new tire
            </h1>
          </div>
        </div>
        {/* 
        https://tailwindui.com/components/application-ui/forms/form-layouts
        */}
        <form
          className="space-y-8 divide-y divide-gray-200"
          onSubmit={handleSubmit(onSubmit)}
        >
          <div className="space-y-8 sm:space-y-5 divide-y divide-gray-200">
            <div className="space-y-6 sm:space-y-5">
              <div>
                <h3 className="text-lg font-medium leading-6 text-gray-900">
                  Entity information
                </h3>
              </div>

              <div className="space-y-6 sm:space-y-5">
                <div className="sm:grid sm:grid-cols-3 sm:gap-4 sm:items-start sm:pt-5 sm:border-t sm:border-gray-200">
                  <label
                    className="block sm:pt-2 sm:mt-px text-sm font-medium text-gray-700"
                    htmlFor="name"
                  >
                    Name
                  </label>
                  <div className="sm:col-span-2 mt-1 sm:mt-0">
                    <input
                      className="block flex-1 w-full min-w-0 sm:text-sm rounded-md border-gray-300 focus:border-os1 focus:ring-os1"
                      id="name"
                      type="text"
                      {...register('name', { required: true })}
                    />
                  </div>
                </div>

                <div className="sm:grid sm:grid-cols-3 sm:gap-4 sm:items-start sm:pt-5 sm:border-t sm:border-gray-200">
                  <label
                    className="block sm:pt-2 sm:mt-px text-sm font-medium text-gray-700"
                    htmlFor="code"
                  >
                    Code
                  </label>
                  <div className="sm:col-span-2 mt-1 sm:mt-0">
                    <input
                      className="block flex-1 w-full min-w-0 sm:text-sm rounded-md border-gray-300 focus:border-os1 focus:ring-os1"
                      id="code"
                      type="text"
                      {...register('uniqueCode', { required: true })}
                    />
                    <p className="mt-2 text-sm text-gray-500">
                      This is a unique code to identify the tire.
                    </p>
                  </div>
                </div>

                <div className="sm:grid sm:grid-cols-3 sm:gap-4 sm:items-start sm:pt-5 sm:border-t sm:border-gray-200">
                  <label
                    className="block sm:pt-2 sm:mt-px text-sm font-medium text-gray-700"
                    htmlFor="owner"
                  >
                    Owner
                  </label>
                  <div className="sm:col-span-2 mt-1 sm:mt-0">
                    <input
                      className="block flex-1 w-full min-w-0 sm:text-sm rounded-md border-gray-300 focus:border-os1 focus:ring-os1"
                      id="owner"
                      type="text"
                      {...register('owner', { required: true })}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-8 sm:pt-10 space-y-6 sm:space-y-5">
              <div>
                <h3 className="text-lg font-medium leading-6 text-gray-900">
                  Properties
                </h3>
                <p className="mt-1 max-w-2xl text-sm text-gray-500">
                  Information about the state of the tire.
                </p>
              </div>
              <div className="space-y-6 sm:space-y-5">
                <div className="sm:grid sm:grid-cols-3 sm:gap-4 sm:items-start sm:pt-5 sm:border-t sm:border-gray-200">
                  <label
                    className="block sm:pt-2 sm:mt-px text-sm font-medium text-gray-700"
                    htmlFor="about"
                  >
                    Is this a new tire?
                  </label>
                  <div className="sm:col-span-2 mt-1 sm:mt-0">
                    <Switch
                      checked={isNew}
                      {...register('properties.isnew', { value: isNew })}
                      className={classNames(
                        isNew ? 'bg-os1' : 'bg-gray-200',
                        'relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-os1 focus:ring-offset-2'
                      )}
                      onChange={setIsNew}
                    >
                      <span className="sr-only">Use setting</span>
                      <span
                        aria-hidden="true"
                        className={classNames(
                          isNew ? 'translate-x-5' : 'translate-x-0',
                          'pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out'
                        )}
                      />
                    </Switch>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-6 gap-x-4 gap-y-6 pt-5 sm:border-t sm:border-gray-200">
                  {properties.map(({ key, name }) => {
                    return (
                      <div className="col-span-2" key={key}>
                        <label
                          className="block sm:pt-2 sm:mt-px text-sm font-medium text-gray-700"
                          htmlFor={key}
                        >
                          {name}
                        </label>
                        <div className="sm:col-span-2 mt-1">
                          <input
                            autoComplete={key}
                            className="block w-full max-w-lg sm:max-w-xs sm:text-sm rounded-md border-gray-300 shadow-sm focus:border-os1 focus:ring-os1"
                            id={key}
                            type="text"
                            {...register(`properties.${key}` as any, {
                              required: true,
                            })}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          <div className="pt-5">
            <div className="flex justify-end">
              <button
                className="py-2 px-4 text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 rounded-md border border-gray-300 focus:ring-2 focus:ring-offset-2 shadow-sm focus:outline-none focus:ring-os1"
                onClick={returnOneStep}
                type="button"
              >
                Cancel
              </button>
              <button
                className="inline-flex justify-center py-2 px-4 ml-3 text-sm font-medium text-white hover:bg-indigo-700 rounded-md border border-transparent focus:ring-2 focus:ring-offset-2 shadow-sm focus:outline-none bg-os1 focus:ring-os1"
                type="submit"
              >
                Save
              </button>
            </div>
          </div>
        </form>
      </div>
    </main>
  );
};
