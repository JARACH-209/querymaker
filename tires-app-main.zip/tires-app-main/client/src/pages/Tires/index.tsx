import { CalendarIcon, ChevronRightIcon } from '@heroicons/react/solid';
import { FunctionComponent } from 'react';
import { Link } from 'react-router-dom';

import { ITire, useGetTires } from '../../api/tires';
import { Badge } from '../../components/Badge';

const TireRow: FunctionComponent<ITire> = ({
  name,
  owner,
  properties,
  id,
  createdAt,
}) => {
  const createdAtDate = new Date(createdAt);
  return (
    <li>
      <Link className="block hover:bg-gray-50" to={`${id}`}>
        <div className="flex items-center py-4 px-4 sm:px-6">
          <div className="sm:flex flex-1 sm:justify-between sm:items-center min-w-0">
            <div className="truncate">
              <div className="flex text-sm">
                <p className="font-medium truncate text-os1">{name}</p>
                <p className="flex-shrink-0 ml-1 font-normal text-gray-500">
                  owned by {owner}
                </p>
              </div>
              <div className="flex mt-2">
                <div className="flex items-center text-sm text-gray-500">
                  <CalendarIcon
                    aria-hidden="true"
                    className="flex-shrink-0 mr-1.5 w-5 h-5 text-gray-400"
                  />
                  <p>
                    Created{' '}
                    <time dateTime={createdAtDate.toDateString()}>
                      {createdAtDate.toDateString()}
                    </time>
                  </p>
                </div>
              </div>
            </div>
            <div className="flex-shrink-0 mt-4 sm:mt-0 sm:ml-5">
              <Badge type={properties.isnew ? 'success' : 'warning'}>
                {properties.isnew ? 'New' : 'Aged'}
              </Badge>
            </div>
          </div>
          <div className="flex-shrink-0 ml-5">
            <ChevronRightIcon
              aria-hidden="true"
              className="w-5 h-5 text-gray-400"
            />
          </div>
        </div>
      </Link>
    </li>
  );
};

export const Tires = () => {
  const { isLoading, data: tires } = useGetTires();

  return (
    <div className="px-4 sm:px-6 lg:px-8">
      <div className="sm:flex sm:items-center">
        <div className="sm:flex-auto">
          <h1 className="text-xl font-semibold text-gray-900">Tires</h1>
          <p className="mt-2 text-sm text-gray-700">
            A list of all the Tires in your account including their name, code,
            and status.
          </p>
        </div>
        <div className="sm:flex-none mt-4 sm:mt-0 sm:ml-16">
          <Link
            className="inline-flex justify-center items-center py-2 px-4 sm:w-auto text-sm font-medium text-white rounded-md border border-transparent focus:ring-2 focus:ring-offset-2 shadow-sm focus:outline-none bg-os1 hover:bg-os1-active focus:ring-os1"
            to="new"
            type="button"
          >
            Add tire
          </Link>
        </div>
      </div>
      <div className="flex flex-col mt-8">
        <div className="overflow-hidden overflow-y-auto align-middle bg-white sm:rounded-md shadow h-[500px]">
          {!isLoading && tires && (
            <ul className="divide-y divide-gray-200">
              {tires.map((tire) => (
                <TireRow key={tire.id} {...tire} />
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
};
