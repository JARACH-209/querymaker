import { FunctionComponent } from 'react';
import { useParams } from 'react-router-dom';

import { useGetTires } from '../../api/tires';
import { Badge } from '../../components/Badge';

export const properties = [
  { name: 'Rim Diameter', key: 'rimdiameter' },
  { name: 'Rim Width', key: 'rimwidth' },
  { name: 'Tread depth', key: 'treaddepth' },
];
export const Tire: FunctionComponent = () => {
  const { data: tires, isLoading } = useGetTires();

  const { tireId } = useParams();

  const selectedTire = tires?.find(({ id }) => tireId === id);

  return (
    <main className="flex-1">
      <div>
        <div className="px-4 sm:px-6 md:px-8 mx-auto space-y-6 max-w-7xl">
          <div className="sm:flex sm:items-center">
            <div className="sm:flex-auto">
              <h1 className="text-xl font-semibold text-gray-900">
                Tire Information for "{selectedTire?.name}"
              </h1>
              <span className="text-sm font-medium text-gray-500">
                {tireId}
              </span>
            </div>
          </div>
          <dl className="grid overflow-hidden grid-cols-1 md:grid-cols-4 mt-5 bg-white rounded-lg divide-y md:divide-y-0 md:divide-x divide-gray-200 shadow">
            {!isLoading &&
              selectedTire &&
              properties.map((item) => {
                const stat = (selectedTire?.properties as any)?.[item.key];
                return (
                  <div className="sm:p-6 py-5 px-4" key={item.name}>
                    <dt className="text-base font-normal text-gray-900">
                      {item.name}
                    </dt>
                    <dd className="flex md:block lg:flex justify-between items-baseline mt-1">
                      <div className="flex items-baseline text-2xl font-semibold text-os1">
                        {stat}
                        <span className="ml-2 text-sm font-medium text-gray-500">
                          inches
                        </span>
                      </div>
                    </dd>
                  </div>
                );
              })}

            <div className="sm:p-6 py-5 px-4">
              <dt className="text-base font-normal text-gray-900">Status</dt>
              <dd className="flex md:block lg:flex justify-between items-baseline mt-1">
                <div className="flex items-baseline text-2xl font-semibold text-os1">
                  <Badge
                    type={
                      selectedTire?.properties.isnew ? 'success' : 'warning'
                    }
                  >
                    {selectedTire?.properties.isnew ? 'New' : 'Aged'}
                  </Badge>
                </div>
              </dd>
            </div>
          </dl>
          <div className="sm:rounded-lg shadow">
            {/* https://tailwindui.com/components/application-ui/data-display/description-lists */}
            <dl className="divide-y divide-gray-200">
              <div className="sm:grid sm:grid-cols-3 sm:gap-4 py-4 sm:py-5 px-6">
                <dt className="text-sm font-medium text-gray-500">Name</dt>
                <dd className="flex sm:col-span-2 mt-1 sm:mt-0 text-sm text-gray-900">
                  <span className="flex-grow">{selectedTire?.name}</span>
                </dd>
              </div>
              <div className="sm:grid sm:grid-cols-3 sm:gap-4 py-4 sm:py-5 px-6">
                <dt className="text-sm font-medium text-gray-500">Code</dt>
                <dd className="flex sm:col-span-2 mt-1 sm:mt-0 text-sm text-gray-900">
                  <span className="flex-grow">{selectedTire?.uniqueCode}</span>
                </dd>
              </div>
              <div className="sm:grid sm:grid-cols-3 sm:gap-4 py-4 sm:py-5 px-6">
                <dt className="text-sm font-medium text-gray-500">Owner</dt>
                <dd className="flex sm:col-span-2 mt-1 sm:mt-0 text-sm text-gray-900">
                  <span className="flex-grow">{selectedTire?.owner}</span>
                </dd>
              </div>
              <div className="sm:grid sm:grid-cols-3 sm:gap-4 py-4 sm:py-5 px-6">
                <dt className="text-sm font-medium text-gray-500">Tenant</dt>
                <dd className="flex sm:col-span-2 mt-1 sm:mt-0 text-sm text-gray-900">
                  <span className="flex-grow">{selectedTire?.tenantId}</span>
                </dd>
              </div>
            </dl>
          </div>
        </div>
      </div>
    </main>
  );
};
