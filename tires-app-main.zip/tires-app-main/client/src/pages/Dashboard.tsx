import {
  ArrowDownIcon,
  ArrowUpIcon,
  CurrencyDollarIcon,
  OfficeBuildingIcon,
} from '@heroicons/react/solid';
import { FunctionComponent } from 'react';
import { Link } from 'react-router-dom';

import { useGetTires } from '../api/tires';
import { BuoyIcon } from '../components/BouyIcon';
import { classNames } from '../helpers/classNames';

export const Dashboard: FunctionComponent = () => {
  const { data: tires } = useGetTires();

  const groupedByOwner = tires?.reduce((previousValue, current) => {
    previousValue[current.owner] = true;

    return previousValue;
  }, {} as any);

  const totalOwners = Object.keys(groupedByOwner || {}).length;

  return (
    <main className="flex-1">
      <div className="px-4 sm:px-6 md:px-8 mx-auto max-w-7xl">
        <h1 className="text-2xl font-semibold text-gray-900">Tires-App</h1>
      </div>

      <div>
        <div className="px-4 sm:px-6 md:px-8 mx-auto max-w-7xl">
          <dl className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 mt-5">
            <div className="overflow-hidden relative px-4 sm:px-6 pt-5 sm:pt-6 pb-12 bg-white rounded-lg shadow">
              <dt>
                <div className="absolute p-3 rounded-md bg-os1">
                  <BuoyIcon aria-hidden="true" className="w-6 h-6 text-white" />
                </div>
                <p className="ml-16 text-sm font-medium text-gray-500 truncate">
                  Total tires
                </p>
              </dt>
              <dd className="flex items-baseline pb-6 sm:pb-7 ml-16">
                <p className="text-2xl font-semibold text-gray-900">
                  {tires?.length}
                </p>
                <p
                  className={classNames(
                    'text-green-600',
                    'ml-2 flex items-baseline text-sm font-semibold'
                  )}
                >
                  <ArrowUpIcon
                    aria-hidden="true"
                    className="flex-shrink-0 self-center w-5 h-5 text-green-500"
                  />
                </p>
                <div className="absolute inset-x-0 bottom-0 py-4 px-4 sm:px-6 bg-gray-50">
                  <div className="text-sm">
                    <Link
                      className="font-medium text-os1 hover:text-os1"
                      to="/tires/new"
                    >
                      Add tire
                    </Link>
                  </div>
                </div>
              </dd>
            </div>
            <div className="overflow-hidden relative px-4 sm:px-6 pt-5 sm:pt-6 pb-12 bg-white rounded-lg shadow">
              <dt>
                <div className="absolute p-3 rounded-md bg-os1">
                  <CurrencyDollarIcon
                    aria-hidden="true"
                    className="w-6 h-6 text-white"
                  />
                </div>
                <p className="ml-16 text-sm font-medium text-gray-500 truncate">
                  Avg. Tread Depth
                </p>
              </dt>
              <dd className="flex items-baseline pb-6 sm:pb-7 ml-16">
                <p className="text-2xl font-semibold text-gray-900">{1.25}</p>
                <p
                  className={classNames(
                    'text-green-600',
                    'ml-2 flex items-baseline text-sm font-semibold'
                  )}
                >
                  <ArrowUpIcon
                    aria-hidden="true"
                    className="flex-shrink-0 self-center w-5 h-5 text-green-500"
                  />
                </p>
                <div className="absolute inset-x-0 bottom-0 py-4 px-4 sm:px-6 bg-gray-50">
                  <div className="text-sm">
                    <Link
                      className="font-medium text-os1 hover:text-os1"
                      to="/tires"
                    >
                      View all<span className="sr-only">tire stats</span>
                    </Link>
                  </div>
                </div>
              </dd>
            </div>

            <div className="overflow-hidden relative px-4 sm:px-6 pt-5 sm:pt-6 pb-12 bg-white rounded-lg shadow">
              <dt>
                <div className="absolute p-3 rounded-md bg-os1">
                  <OfficeBuildingIcon
                    aria-hidden="true"
                    className="w-6 h-6 text-white"
                  />
                </div>
                <p className="ml-16 text-sm font-medium text-gray-500 truncate">
                  Total Companies
                </p>
              </dt>
              <dd className="flex items-baseline pb-6 sm:pb-7 ml-16">
                <p className="text-2xl font-semibold text-gray-900">
                  {totalOwners}
                </p>
                <p
                  className={classNames(
                    'text-red-600',
                    'ml-2 flex items-baseline text-sm font-semibold'
                  )}
                >
                  <ArrowDownIcon
                    aria-hidden="true"
                    className="flex-shrink-0 self-center w-5 h-5 text-red-500"
                  />
                </p>
              </dd>
            </div>
          </dl>
        </div>
      </div>
    </main>
  );
};
