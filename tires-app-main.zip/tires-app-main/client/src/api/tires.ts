import { sharedAccessBundle } from 'header/AuthenticatedHeader';
import {
  QueryFunction,
  QueryKey,
  useQuery,
  UseQueryOptions,
  UseQueryResult,
} from 'react-query';

interface Meta {
  totalElements: number;
}

interface Properties {
  isnew: boolean;
  rimdiameter: string;
  rimwidth: string;
  treaddepth: string;
}

interface CreatedBy {
  id: number;
  name: string;
}

interface UpdatedBy {
  id: number;
  name: string;
}

export interface ITire {
  id: string;
  uniqueCode: string;
  entityId: string;
  tenantId: string;
  appId: string;
  name: string;
  entityName: string;
  owner: string;
  properties: Properties;
  createdBy: CreatedBy;
  createdAt: any;
  updatedBy: UpdatedBy;
  updatedAt: any;
}

interface Data {
  meta: Meta;
  entityInstances: ITire[];
}

interface Body {}

interface Request {
  uri: string;
  method: string;
  queryString: string;
  body: Body;
}

interface TiresResponse {
  data: Data;
  request: Request;
}

const getHeaders = () => ({
  'X-COREOS-ACCESS': `${sharedAccessBundle.value.accessToken}`,
  'X-COREOS-REQUEST-ID': Date.now().toString(),
  'X-COREOS-TID': sharedAccessBundle.value.tenantId,
});

const getTires = async () =>
  fetch(`/api/tires`, { headers: getHeaders() })
    .then((response) => response.json())
    .then(({ data }: TiresResponse) => {
      return data.entityInstances;
    });

export const getTiresQueryKey = () => [`/api/tires`];

type AsyncReturnType<T extends (...args: any) => Promise<any>> = T extends (
  ...args: any
) => Promise<infer R>
  ? R
  : any;

type TError = unknown;

export const useGetTires = <
  TData = AsyncReturnType<typeof getTires>
>(options?: {
  query?: UseQueryOptions<AsyncReturnType<typeof getTires>, TError, TData>;
}): UseQueryResult<TData, TError> & { queryKey: QueryKey } => {
  const { query: queryOptions } = options || {};

  const queryKey = queryOptions?.queryKey ?? getTiresQueryKey();

  const queryFn: QueryFunction<AsyncReturnType<typeof getTires>> = () =>
    getTires();

  const query = useQuery<AsyncReturnType<typeof getTires>, TError, TData>(
    queryKey,
    queryFn,
    queryOptions
  );

  return {
    queryKey,
    ...query,
  };
};

interface PostTireResponse {
  data: {
    id: string;
  };
  request: Request;
}

export const postTire = async (
  tire: Pick<ITire, 'name' | 'owner' | 'uniqueCode' | 'properties'>
) => {
  const result = await fetch(`/api/tires`, {
    method: 'POST',
    body: JSON.stringify(tire),

    headers: {
      ...getHeaders(),

      'Content-Type': 'application/json',
    },
  });

  const success = (await result.json()) as PostTireResponse;

  return success.data?.id;
};
