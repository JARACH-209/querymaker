/* This example requires Tailwind CSS v2.0+ */
import { FunctionComponent } from 'react';
import { Link, useMatch, useParams } from 'react-router-dom';

import { BuoyIcon } from './BouyIcon';

const Crumb: FunctionComponent<{ name: string; href: string }> = ({
  name,
  href,
}) => {
  const isCurrent = useMatch(href);
  return (
    <li className="flex" key={name}>
      <div className="flex items-center">
        <svg
          aria-hidden="true"
          className="flex-shrink-0 w-6 h-full text-gray-200"
          fill="currentColor"
          preserveAspectRatio="none"
          viewBox="0 0 24 44"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path d="M.293 0l22 22-22 22h1.414l22-22-22-22H.293z" />
        </svg>
        <Link
          aria-current={isCurrent ? 'page' : undefined}
          className="ml-4 text-xs font-medium text-gray-500 hover:text-gray-700"
          to={href}
        >
          {name}
        </Link>
      </div>
    </li>
  );
};

export const Breadcrumb = () => {
  const { tireId } = useParams();

  return (
    <nav
      aria-label="Breadcrumb"
      className="flex bg-white border-b border-gray-200"
    >
      <ol className="flex px-4 sm:px-6 lg:px-8 mx-auto space-x-4 w-full ">
        <li className="flex">
          <Link
            className="flex items-center text-gray-400 hover:text-gray-500"
            to="/tires"
          >
            <BuoyIcon
              aria-hidden="true"
              className="flex-shrink-0 mr-2 w-5 h-5"
            />

            <span className="text-xs">Tires</span>
          </Link>
        </li>

        {tireId && <Crumb href="" name={tireId} />}

        {!tireId && <Crumb href="" name="New" />}
      </ol>
    </nav>
  );
};
