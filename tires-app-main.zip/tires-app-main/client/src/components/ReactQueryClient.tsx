import React, { FunctionComponent, ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from 'react-query';
import { ReactQueryDevtools } from 'react-query/devtools';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: Infinity,
      refetchOnWindowFocus: false,
      refetchOnReconnect: false,
      retry: false,
      refetchOnMount: false,
      notifyOnChangeProps: 'tracked',
    },
  },
});

export const ReactQueryClientProvider: FunctionComponent<{
  children: ReactNode;
  showDevTools?: boolean;
}> = ({ children, showDevTools = true }) => (
  <QueryClientProvider client={queryClient}>
    {showDevTools && <ReactQueryDevtools />}
    {children}
  </QueryClientProvider>
);
