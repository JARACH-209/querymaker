/*
    https://tailwindui.com/components/application-ui/elements/badges
*/

import { FunctionComponent, ReactNode } from 'react';

import { classNames } from '../helpers/classNames';

export const Badge: FunctionComponent<{
  children: ReactNode;
  type: 'success' | 'warning';
}> = ({ type, children }) => (
  <span
    className={classNames(
      type === 'success'
        ? 'bg-green-100 text-green-800'
        : 'bg-yellow-100 text-yellow-800',

      'inline-flex items-center rounded-full bg-green-100 px-3 py-0.5 text-sm font-medium text-green-800'
    )}
  >
    {children}
  </span>
);
