import { HomeIcon } from '@heroicons/react/outline';
import { sharedAccessBundle } from 'header/AuthenticatedHeader';
import { FunctionComponent, useEffect, useState } from 'react';
import {
  Link,
  Outlet,
  Route,
  Routes,
  useLocation,
  useMatch,
} from 'react-router-dom';

import { classNames } from '../helpers/classNames';
import { BuoyIcon } from './BouyIcon';
import { Breadcrumb } from './Breadcrumb';

interface INavigationItem {
  name: string;
  href: string;
  icon: (props: any) => JSX.Element;
}

const navigation: INavigationItem[] = [
  { name: 'Dashboard', href: '/', icon: HomeIcon },
  { name: 'Tires', href: '/tires', icon: BuoyIcon },
];

const NavigationLink: FunctionComponent<INavigationItem> = ({
  href,
  name,
  icon: ItemIcon,
}) => {
  let isCurrent = !!useMatch(`${href}*`);
  const { pathname } = useLocation();
  if (href === '/') isCurrent = pathname === href;

  return (
    <Link
      className={classNames(
        isCurrent
          ? 'bg-gray-100 text-gray-900'
          : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900',
        'group flex items-center px-2 py-2 text-sm font-medium rounded-md'
      )}
      key={name}
      to={href}
    >
      <ItemIcon
        aria-hidden="true"
        className={classNames(
          isCurrent
            ? 'text-gray-500'
            : 'text-gray-400 group-hover:text-gray-500',
          'mr-3 flex-shrink-0 h-6 w-6'
        )}
      />
      {name}
    </Link>
  );
};

export const SidebarLayout: FunctionComponent = () => {
  const [accessToken, setAccessToken] = useState<undefined | string>();

  useEffect(() => {
    sharedAccessBundle.subscribe(() => {
      if (sharedAccessBundle.value.accessToken) {
        setAccessToken(sharedAccessBundle.value.accessToken);
      }
    });
  }, []);

  return (
    <>
      <div className="flex fixed bottom-0 flex-col w-64 top-[72px]">
        {/* 
        
        Based upon the tailwindcss example 
        https://tailwindui.com/components/application-ui/application-shells/sidebar#component-ba754bf465a594eb075045eb9e940b60
        */}
        <div className="flex flex-col flex-1 min-h-0 bg-white border-r border-gray-200">
          <div className="flex overflow-y-auto flex-col flex-1">
            <nav className="flex-1 py-4 px-2 space-y-1">
              {navigation.map((item) => {
                return <NavigationLink key={item.href} {...item} />;
              })}
            </nav>
          </div>
        </div>
      </div>
      <Routes>
        <Route
          element={
            <div className="pl-64">
              <Breadcrumb />
            </div>
          }
          path="/tires/:any"
         />
      </Routes>
      <div className="flex flex-col py-6 pl-64">
        {accessToken && <Outlet />}
      </div>
    </>
  );
};
