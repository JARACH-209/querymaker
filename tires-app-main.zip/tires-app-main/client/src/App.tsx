import initialize from 'header/initialize';
import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';

import { SidebarLayout } from './components/SidebarLayout';
import { Dashboard } from './pages/Dashboard';
import { Tires } from './pages/Tires';
import { NewTire } from './pages/Tires/New';
import { Tire } from './pages/Tires/Tire';

initialize();

const App = () => (
  <BrowserRouter>
    <Routes>
      <Route element={<SidebarLayout />} path="/">
        <Route element={<Dashboard />} index={true} />

        <Route path="/tires">
          <Route element={<Tires />} index={true} />
          <Route element={<Tire />} path=":tireId" />
          <Route element={<NewTire />} path="new" />
        </Route>
      </Route>
    </Routes>
  </BrowserRouter>
);

export default App;
